import React from 'react';

function ColumnComponent(){
    return(
        <>
        <td>Name</td>
        <td>Devika</td>
        </>
    )
}
export default ColumnComponent;