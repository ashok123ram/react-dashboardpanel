import React from "react";

export default function MyCom(){
    return(
        <div>
            <h1>My function component</h1>
        </div>
    );
}